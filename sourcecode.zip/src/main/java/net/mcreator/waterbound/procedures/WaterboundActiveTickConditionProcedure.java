package net.mcreator.waterbound.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.waterbound.WaterBoundMod;

import java.util.Map;
import java.util.Collection;

public class WaterboundActiveTickConditionProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency entity for procedure WaterboundActiveTickCondition!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity.isInWaterOrBubbleColumn()) {
			if (entity instanceof LivingEntity)
				((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.WATER_BREATHING, (int) 320, (int) 0, (true), (false)));
		} else {
			if (!(new Object() {
				boolean check(Entity _entity) {
					if (_entity instanceof LivingEntity) {
						Collection<EffectInstance> effects = ((LivingEntity) _entity).getActivePotionEffects();
						for (EffectInstance effect : effects) {
							if (effect.getPotion() == Effects.WATER_BREATHING)
								return true;
						}
					}
					return false;
				}
			}.check(entity))) {
				entity.attackEntityFrom(DamageSource.DROWN, (float) 2);
			}
		}
	}
}
