package net.mcreator.waterbound.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import net.mcreator.waterbound.WaterBoundMod;

import java.util.Map;

public class UndeadEffectOnEffectActiveTickProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency world for procedure UndeadEffectOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency x for procedure UndeadEffectOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency y for procedure UndeadEffectOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency z for procedure UndeadEffectOnEffectActiveTick!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency entity for procedure UndeadEffectOnEffectActiveTick!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		if (world.getLight(new BlockPos((int) x, (int) (y + 1), (int) z)) > 13) {
			entity.attackEntityFrom(DamageSource.IN_FIRE, (float) 2);
		}
	}
}
