package net.mcreator.waterbound.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.waterbound.WaterBoundMod;

import java.util.Map;

public class FlameOnEffectActiveTickProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency entity for procedure FlameOnEffectActiveTick!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity.isBurning()) {
			if (entity instanceof LivingEntity)
				((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, (int) 60, (int) 0, (true), (false)));
		} else {
			if (entity.isInLava()) {
				if (entity instanceof LivingEntity)
					((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, (int) 60, (int) 0, (true), (false)));
			} else {
				entity.attackEntityFrom(DamageSource.GENERIC, (float) 2);
				if (entity.isInWaterRainOrBubbleColumn()) {
					entity.attackEntityFrom(DamageSource.GENERIC, (float) 4);
					if (entity.isInWaterOrBubbleColumn()) {
						entity.attackEntityFrom(DamageSource.GENERIC, (float) 6);
					}
				}
			}
		}
	}
}
