package net.mcreator.waterbound.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import net.mcreator.waterbound.WaterBoundMod;

import java.util.Map;

public class WaterAdversityOnEffectActiveTickProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				WaterBoundMod.LOGGER.warn("Failed to load dependency entity for procedure WaterAdversityOnEffectActiveTick!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity.isInWaterOrBubbleColumn()) {
			entity.attackEntityFrom(DamageSource.DRYOUT, (float) 3);
		} else if (entity.isInWaterRainOrBubbleColumn()) {
			entity.attackEntityFrom(DamageSource.DRYOUT, (float) 1);
		}
	}
}
